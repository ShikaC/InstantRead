# 带附件的 Markdown 包

本包用于 R4.2 验收：Markdown 入口与相对图片一起打包为 ZIP。

## 包内相对图片（应可见）

![紫色方块](assets/purple-square.png)

## 网络图片（应被拦截）

![网络图片](https://example.com/remote.png)

## 内嵌图片（应可见）

![内嵌图片](data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAQAAAAECAIAAAAmkwkpAAAAGElEQVR4nGNk+M8AB0wMDBiYGJiAIAMAJ5oBAvzJN3kAAAAASUVORK5CYII=)
